public struct BreedFavorites {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
