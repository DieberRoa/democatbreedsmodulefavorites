//
//  SwiftUIView.swift
//  
//
//  Created by Dieber A Roa M on 16/11/22.
//

import SwiftUI

public struct BreedFavoritesView: View {
    
    
    public init() {
        
    }
    
    public var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        BreedFavoritesView()
    }
}
